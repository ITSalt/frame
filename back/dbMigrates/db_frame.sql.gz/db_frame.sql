-- Adminer 4.8.1 MySQL 5.5.5-10.7.8-MariaDB-1:10.7.8+maria~ubu2004 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `categoryGroups`;
CREATE TABLE `categoryGroups` (
  `id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `idParent` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(150) DEFAULT NULL,
  `isDeleted` enum('NO','YES') NOT NULL DEFAULT 'NO',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idLastUserOperation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `categoryGroups` (`id`, `name`, `idParent`, `description`, `image`, `isDeleted`, `created`, `updated`, `idLastUserOperation`) VALUES
('7c6fdf47-7173-47b6-abca-c601c124d614',	'Компьютерные компоненты',	NULL,	'Память, видеокарты, звуковухи',	'b5be13a7-eea1-4754-8ebc-88742c7c093f.png',	'NO',	'2023-08-22 01:03:00',	'2023-08-22 01:03:00',	'id1'),
('83b81147-6db2-4c24-8121-fbc8832b3992',	'Периферийные платы',	NULL,	'Платы с различных высокопроизводительных устройств',	'71d84f05-d188-4021-a42f-7c7dd1b83e8e.png',	'NO',	'2023-08-22 00:59:45',	'2023-08-22 00:59:45',	'id1'),
('94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'Платы с различной техники',	NULL,	'Cоветская, старая импортная, военная',	'454e8de5-c636-4f5a-b9b0-b837649f3165.png',	'NO',	'2023-08-22 00:44:09',	'2023-08-22 00:51:32',	'id1'),
('ea8ae4c6-a619-464f-92de-7017d7c98028',	'Компьютерные материнские платы',	NULL,	'',	'e335a2c3-e3c7-4c66-8198-0ac151dc1b74.png',	'NO',	'2023-08-22 00:54:53',	'2023-08-22 00:54:53',	'id1');

DROP TABLE IF EXISTS `categoryItems`;
CREATE TABLE `categoryItems` (
  `id` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `idGroup` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `measureUnit` varchar(10) NOT NULL DEFAULT 'шт.',
  `image` varchar(150) DEFAULT NULL,
  `slangTags` text DEFAULT NULL,
  `isDeleted` enum('NO','YES') NOT NULL DEFAULT 'NO',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idLastUserOperation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idGroup` (`idGroup`),
  KEY `slangTags` (`slangTags`(1024)),
  KEY `isDeleted` (`isDeleted`),
  CONSTRAINT `categoryItems_ibfk_1` FOREIGN KEY (`idGroup`) REFERENCES `categoryGroups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `categoryItems` (`id`, `name`, `idGroup`, `description`, `measureUnit`, `image`, `slangTags`, `isDeleted`, `created`, `updated`, `idLastUserOperation`) VALUES
('098099d1-c5d0-424c-b59f-11ec09c8a41c',	'МОНИТОРНАЯ ПЛАТА (ИМПОРТ)',	'94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'Стороны разного цвета, от мониторов, бесперебойников, блоков питания, силовые платы. Платы от билбордов / светофоров / led ламп в эту позицию не идут.',	'шт.',	'14202a62-ae66-419c-99c4-ee00b832a6f3.png',	'мониторка, импорт, телевизионка',	'NO',	'2023-08-22 00:49:02',	'2023-08-22 00:49:02',	'id1'),
('1a907ace-c131-4e3a-a2d4-f86faa99a4c4',	'ОПЕРАТИВНАЯ ПАМЯТЬ RAM ЖЕЛТАЯ',	'7c6fdf47-7173-47b6-abca-c601c124d614',	'данный плата является компьютерным компонентом и вставляется в материнские платы.',	'шт.',	'efc26815-8047-404b-85c7-4d72096bc657.png',	'рамка, рамка желтая, оперативка, оперативка желтая',	'NO',	'2023-08-22 01:03:22',	'2023-08-22 01:03:22',	'id1'),
('1cc1ae13-ec68-4970-aaef-f6064cf8d3cf',	'МАТЕРИНСКИЕ ПЛАТЫ ДО ПОКОЛЕНИЯ PENTIUM 4',	'ea8ae4c6-a619-464f-92de-7017d7c98028',	'Абсолютно целая и не грабленная плата. Снимается только батарейка, алюминий.',	'шт.',	'6bdcea75-c7fa-4d22-ae15-4927888ea4e0.png',	'старые матери, старые мамки',	'NO',	'2023-08-22 00:57:06',	'2023-08-22 00:57:06',	'id1'),
('272eebbe-595f-473a-8e39-6300df0d29af',	'ПЛАТА К-155 СОВЕТСКАЯ',	'94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'Микросхема к 155 должна занимать не менее 80% платы',	'шт.',	'f9380b93-fb46-43b5-9f6f-01f5f41caf45.png',	'к 155',	'NO',	'2023-08-22 00:51:17',	'2023-08-22 00:51:17',	'id1'),
('27e361ae-4717-4c4c-acfc-b1de9d5ea1f5',	'ВИДЕОКАРТА',	'7c6fdf47-7173-47b6-abca-c601c124d614',	'данная плата является компьютерным компонентом и вставляется в материнские платы.. ОБЯЗАТЕЛЬНО С желтыми ламелями, без металлической планки, кулера и радиатора.',	'шт.',	'a9aa54c6-7ba2-469e-ad40-1e46ae8b2e31.png',	'видюха, видюхи, видео',	'NO',	'2023-08-22 01:08:29',	'2023-08-22 01:08:29',	'id1'),
('3e5fdbeb-3ad3-44a0-8bac-407efb44fc91',	'ПЛАТА  К-155 Советская бедная',	'94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'Микросхема к 155 должна занимать не менее 40% платы',	'шт.',	'5820f940-bf59-4976-ab3f-e87fa2990651.png',	'к 155 обедненная',	'NO',	'2023-08-22 00:50:29',	'2023-08-22 00:50:29',	'id1'),
('54b72536-e098-468a-8301-818393f55f28',	'ЗВУКОВАЯ, СЕТЕВАЯ КАРТА',	'7c6fdf47-7173-47b6-abca-c601c124d614',	'данный плата является компьютерным компонентом и вставляется в материнские платы. ОБЯЗАТЕЛЬНО С желтыми ламелями, без металлической планки, кулера и радиатора.',	'шт.',	'adc7e26f-0620-422c-8525-c740a88878c2.png',	'звук, сеть',	'NO',	'2023-08-22 01:11:38',	'2023-08-22 01:11:38',	'id1'),
('56df2476-5a22-4e6d-8980-f6182d16115b',	'ПЛАТЫ ОТ ИГРОВЫХ АВТОМАТОВ',	'83b81147-6db2-4c24-8121-fbc8832b3992',	'Такие платы можно встретить разбирая игровой автомат. Абсолютно целые, со всеми ламелями и микросхемами.',	'шт.',	'cc26eb98-5f22-48c5-a9cf-83836af744bb.png',	'игровухи',	'NO',	'2023-08-22 01:01:03',	'2023-08-22 01:01:03',	'id1'),
('5e0e79d8-1012-4156-99a2-2e3e545b2c71',	'МАТЕРИНСКИЕ ПЛАТЫ НОВЫЕ',	'ea8ae4c6-a619-464f-92de-7017d7c98028',	'Абсолютно целая и не грабленная плата. Снимается только батарейка, алюминий, съемная крышка процессора.',	'шт.',	'2e82bb40-7467-4a3c-b1a9-6d47ee9e5ba1.png',	'матери, мамки',	'NO',	'2023-08-22 00:55:23',	'2023-08-22 00:55:23',	'id1'),
('6c37aba3-898d-4b55-b9eb-ab761222e360',	'СРЕЗКА С ПЛАТ (ДЕТАЛИ)',	'94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'МЛТ, Диоды,КТ,микросхемы, а также СП и Реле до 3 см.  Без картона, упаковки.  Не принимаем: переключатели, лампы, конденсаторы, карболитовые ШР и МНЦ разъемы, СП и Реле больше 3 см',	'шт.',	'a0a03a9d-9219-4748-9338-9143d3aa0a89.png',	'срезка',	'NO',	'2023-08-22 00:45:45',	'2023-08-22 00:47:07',	'id1'),
('85874e33-116b-4294-a51d-e80e135bb98c',	'ПЛАТЫ ПЕРИФЕРИИ ЗЕЛЕНЫЕ С ЖЕЛТЫМИ ЭЛЕМЕНТАМИ',	'83b81147-6db2-4c24-8121-fbc8832b3992',	'Такие платы можно встретить в различном периферийном оборудовании. Обязательно Наличие желтых разъемов + процессоров',	'шт.',	'3c032865-5fce-4edc-b1cd-49548ebe6248.png',	'периферия, мало элементов',	'NO',	'2023-08-22 01:00:13',	'2023-08-22 01:00:13',	'id1'),
('8ca71441-c67e-4ce4-a833-062d177f5de5',	'МАТЕРИНСКИЕ ПЛАТЫ ОТ НОУТБУКА',	'ea8ae4c6-a619-464f-92de-7017d7c98028',	'Абсолютно целая и не грабленная плата. Снимается только батарейка, алюминий.',	'шт.',	'24a006c0-49d7-4c8e-89f7-fbc912b9de12.png',	'ноуты, матери ноут, мамки ноут',	'NO',	'2023-08-22 00:58:27',	'2023-08-22 00:58:27',	'id1'),
('aa23906d-23a5-4844-b9b8-c1c9bb8f092b',	'ОПЕРАТИВНАЯ ПАМЯТЬ RAM БЕЛАЯ',	'7c6fdf47-7173-47b6-abca-c601c124d614',	'данная плата является компьютерным компонентом и вставляется в материнские платы.',	'шт.',	'd6a4c0a6-4fdf-462a-8992-e2e905ad0163.png',	'рамка белая, оперативка белая',	'NO',	'2023-08-22 01:04:07',	'2023-08-22 01:04:07',	'id1'),
('b1123d41-8593-4fa1-9032-28665614665a',	'платы СЕРВЕРНЫЕ класса периферии',	'83b81147-6db2-4c24-8121-fbc8832b3992',	'Такие платы можно встретить в различном периферийном оборудовании используемом в серверном узле. Наличие желтых разъемов + не менее 3-х желтых процессоров.',	'шт.',	'f8878ded-a430-4def-bf6c-62606e997e81.png',	'сервак, много элементов',	'NO',	'2023-08-22 01:01:46',	'2023-08-22 01:01:46',	'id1'),
('b3709ca0-13de-4936-97f0-07c843377016',	'РАЗНОСОРТНЫЕ ПЛАТЫ (МИКС)',	'94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'Строго без импортной мониторной платы. Сюда идут платы СССР производства, платы которые не попадают в другие категории. Одна из самых популярных категорий.',	'шт.',	'5215ad7b-1554-4469-b160-49c39130c79d.png',	'микс, бытовуха, советы, ссср',	'NO',	'2023-08-22 00:44:59',	'2023-08-22 00:48:05',	'id1'),
('e3f5d8cf-ed12-49a0-ac17-9ba71331111c',	'МАТЕРИНСКАЯ ПЛАТА СЕРВЕРНАЯ',	'ea8ae4c6-a619-464f-92de-7017d7c98028',	'Два и более процессоров, целая, не грабленая',	'шт.',	'ffba8940-6137-4285-b7ba-dcfedfab8982.png',	'сервак, сервер, матери сервер, мамки сервак',	'NO',	'2023-08-22 00:57:45',	'2023-08-22 00:57:45',	'id1'),
('e52cad6e-d354-4a8a-8b06-59e710ce654b',	'МАТЕРИНСКАЯ ПЛАТА ГРАБЛЕНАЯ',	'ea8ae4c6-a619-464f-92de-7017d7c98028',	'Материнские платы, новые,старые,серверные,ноутбук, - грабленые и ломаные',	'шт.',	'79fa9585-bad7-4767-8de8-a8f0436fd079.png',	'матери бендые, мамки бедные, матери грабленные, мамки грабленные',	'NO',	'2023-08-22 00:56:13',	'2023-08-22 00:56:13',	'id1'),
('ec3be237-f273-4d47-bb0c-880e32090f9c',	'ТЕКСТОЛИТ (ДОСКИ)',	'94384b1e-8e22-4a12-b50a-9fc250ef65c9',	'',	'шт.',	'4bac8ec4-d9f5-4ac9-8f45-e067396a2664.png',	'1 сорт , - Текстолит СССР и Импорт с остатками припоя (дорожек), без металлических частей.   2 сорт , - Текстолит без лужения и дорожек, пустые заготовки, обрезь плат',	'NO',	'2023-08-22 00:52:18',	'2023-08-22 00:52:18',	'id1');

DROP TABLE IF EXISTS `orderPositions`;
CREATE TABLE `orderPositions` (
  `id` varchar(50) NOT NULL,
  `idWH` varchar(50) NOT NULL,
  `idOrder` varchar(50) NOT NULL,
  `orderQuantity` decimal(10,2) NOT NULL,
  `byedQuantity` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp(),
  `idLastUserOperation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idOrder_idWH` (`idOrder`,`idWH`),
  KEY `idWH` (`idWH`),
  KEY `idLastUserOperation` (`idLastUserOperation`),
  CONSTRAINT `orderPositions_ibfk_1` FOREIGN KEY (`idWH`) REFERENCES `warehouse` (`id`),
  CONSTRAINT `orderPositions_ibfk_2` FOREIGN KEY (`idOrder`) REFERENCES `orders` (`id`),
  CONSTRAINT `orderPositions_ibfk_3` FOREIGN KEY (`idLastUserOperation`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `orderPositions` (`id`, `idWH`, `idOrder`, `orderQuantity`, `byedQuantity`, `created`, `updated`, `idLastUserOperation`) VALUES
('025ab8a7-f542-4b77-b651-f8787e4050dd',	'829fd026-1608-4ce1-ba6a-bbde4be4b5f4',	'cf4de4cb-c62f-4ecd-a341-fee61d02b25f',	459.00,	0.00,	'2023-08-28 21:26:35',	'2023-08-28 21:26:35',	'id1'),
('0aac65f5-16fa-4422-aaa9-db95c2cc6f90',	'424464a9-7c2c-4bdd-9e6a-166acba1def6',	'dabdc6e1-e146-4550-b23c-5ed841ab7bb9',	1.00,	0.00,	'2023-08-29 17:54:39',	'2023-08-29 17:54:39',	'id2'),
('113ed236-26c7-43e6-bae0-1e5060364fc0',	'e1344139-94b4-4e6a-bc90-9caf6a1dca7d',	'190b14e6-71f9-46b5-89da-49d065552f8b',	12.00,	0.00,	'2023-08-29 09:40:20',	'2023-08-29 09:40:20',	'id2'),
('26532e4c-8428-4a37-8235-f9300e0196c8',	'5a3311e5-2c64-4e44-9e73-155df0d00122',	'dc074391-d971-485d-822c-4847e4c528f3',	45.00,	0.00,	'2023-08-29 17:56:14',	'2023-08-29 17:56:14',	'id2'),
('2d5eb829-e0eb-4afc-86d2-625de4dad93f',	'57ee1bc1-96d4-491e-906d-825b61689b94',	'df48271d-32cd-4541-b8d5-2a74e6e5ed6f',	10.00,	0.00,	'2023-08-29 00:25:16',	'2023-08-29 00:25:16',	'id1'),
('52514846-6a6a-4a5a-b15a-1a384a0af506',	'5a3311e5-2c64-4e44-9e73-155df0d00122',	'dabdc6e1-e146-4550-b23c-5ed841ab7bb9',	50.00,	0.00,	'2023-08-29 17:53:33',	'2023-08-29 17:53:33',	'id2'),
('651b305b-341f-4013-913e-2c4b609a4b96',	'57ee1bc1-96d4-491e-906d-825b61689b94',	'0f03340c-e034-4d77-ba6a-d0a7e9c6b0e4',	10.00,	0.00,	'2023-08-29 00:28:53',	'2023-08-29 00:28:53',	'id1'),
('9a1dbafa-439d-480b-b2a5-53608ebfa409',	'424464a9-7c2c-4bdd-9e6a-166acba1def6',	'190b14e6-71f9-46b5-89da-49d065552f8b',	2.00,	0.00,	'2023-08-29 09:40:18',	'2023-08-29 09:40:18',	'id2'),
('9d148e24-cef4-44b2-90f0-f58405d827b6',	'cb6880d6-dbb0-4567-8c4c-fc3cc25d0545',	'cf4de4cb-c62f-4ecd-a341-fee61d02b25f',	14.00,	0.00,	'2023-08-28 22:18:49',	'2023-08-28 22:18:49',	'id1'),
('ba3bea31-db10-4d31-a531-3b28ca2fdd86',	'c0fb91a1-b473-4ad5-9c9f-34a43fd246af',	'dabdc6e1-e146-4550-b23c-5ed841ab7bb9',	2.00,	0.00,	'2023-08-29 17:54:44',	'2023-08-29 17:54:44',	'id2'),
('bd24b8dd-0d9d-4c2b-b109-536a3f2401e0',	'57ee1bc1-96d4-491e-906d-825b61689b94',	'12abe702-0e30-4aba-a53d-a347e44ba781',	10.00,	0.00,	'2023-08-29 00:36:29',	'2023-08-29 00:36:29',	'id1'),
('d3ab7475-a376-4557-ae41-b261ba63fe4b',	'0aefaa5e-951f-420c-b827-f1947424f724',	'cf4de4cb-c62f-4ecd-a341-fee61d02b25f',	5.00,	0.00,	'2023-08-28 22:10:36',	'2023-08-28 22:10:36',	'id1'),
('dc1ea1ff-150e-4ca2-a588-f9f0839dba34',	'424464a9-7c2c-4bdd-9e6a-166acba1def6',	'd19454d9-792c-48c3-9d1e-66c1d6c25cf5',	5.00,	0.00,	'2023-08-29 09:36:46',	'2023-08-29 09:36:46',	'id2'),
('e498b16f-ba18-45b6-88e7-4e884e68e01b',	'e90e60a1-9e44-4e7a-8695-3a96ec5036be',	'50403d0d-8095-467a-bf19-07e574c667d0',	2.00,	0.00,	'2023-08-29 09:40:02',	'2023-08-29 09:40:02',	'id2');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` varchar(50) NOT NULL,
  `orderNum` varchar(50) NOT NULL,
  `idOwner` varchar(50) NOT NULL,
  `state` enum('OPEN','SENDED','BOOKED','CLOSED','DECLINED') NOT NULL DEFAULT 'OPEN',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idLastUserOperation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderNum_created` (`orderNum`,`created`),
  KEY `idOwner` (`idOwner`),
  KEY `idLastUserOperation` (`idLastUserOperation`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`idOwner`) REFERENCES `users` (`id`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`idLastUserOperation`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `orders` (`id`, `orderNum`, `idOwner`, `state`, `created`, `updated`, `idLastUserOperation`) VALUES
('0f03340c-e034-4d77-ba6a-d0a7e9c6b0e4',	'6371-098234-6760',	'id1',	'SENDED',	'2023-08-29 00:27:47',	'2023-08-29 00:29:14',	'id1'),
('1054cf22-b35d-479e-9baa-d4df1c1461eb',	'6371-098713-8770',	'id1',	'OPEN',	'2023-08-29 00:42:16',	'2023-08-29 00:42:16',	'id1'),
('12abe702-0e30-4aba-a53d-a347e44ba781',	'6371-098695-5096',	'id1',	'SENDED',	'2023-08-29 00:29:14',	'2023-08-29 00:42:16',	'id1'),
('190b14e6-71f9-46b5-89da-49d065552f8b',	'6371-076023-0006',	'id2',	'SENDED',	'2023-08-29 09:40:06',	'2023-08-29 09:40:23',	'id2'),
('50403d0d-8095-467a-bf19-07e574c667d0',	'6371-076211-3548',	'id2',	'SENDED',	'2023-08-29 09:37:13',	'2023-08-29 09:40:06',	'id2'),
('cf4de4cb-c62f-4ecd-a341-fee61d02b25f',	'6371-010020-0361',	'id1',	'SENDED',	'2023-08-28 17:16:42',	'2023-08-29 00:13:32',	'id1'),
('d19454d9-792c-48c3-9d1e-66c1d6c25cf5',	'6371-083022-5798',	'id2',	'SENDED',	'2023-08-29 08:16:40',	'2023-08-29 09:37:13',	'id2'),
('dabdc6e1-e146-4550-b23c-5ed841ab7bb9',	'6371-076001-4888',	'id2',	'SENDED',	'2023-08-29 09:40:23',	'2023-08-29 17:55:18',	'id2'),
('dc074391-d971-485d-822c-4847e4c528f3',	'6371-102768-5858',	'id2',	'OPEN',	'2023-08-29 17:55:18',	'2023-08-29 17:55:18',	'id2'),
('df48271d-32cd-4541-b8d5-2a74e6e5ed6f',	'6371-094068-8020',	'id1',	'SENDED',	'2023-08-29 00:13:38',	'2023-08-29 00:27:47',	'id1');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `passwd` varchar(255) NOT NULL,
  `fName` varchar(150) DEFAULT NULL,
  `lName` varchar(150) DEFAULT NULL,
  `mName` varchar(150) DEFAULT NULL,
  `phone` varchar(12) NOT NULL,
  `avatar` varchar(150) DEFAULT NULL,
  `role` enum('ROOT','SELLER','BUYER') NOT NULL DEFAULT 'SELLER',
  `isDeleted` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `needPwdChange` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `idLastUserOperation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email_passwd` (`email`,`passwd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `users` (`id`, `email`, `passwd`, `fName`, `lName`, `mName`, `phone`, `avatar`, `role`, `isDeleted`, `needPwdChange`, `created`, `updated`, `idLastUserOperation`) VALUES
('id1',	'mnikitin@mnikitin.ru',	'3049a1f0f1c808cdaa4fbed0e01649b1',	'Max',	'Nikitin',	'Genn',	'+79165384071',	'70a71334-c103-4d60-a6b5-97ec1fc1dd3f.png',	'ROOT',	'NO',	'NO',	'2023-07-09 22:51:13',	'2023-08-22 07:58:48',	'id1'),
('id2',	's@s.s',	'3049a1f0f1c808cdaa4fbed0e01649b1',	'Продавец',	NULL,	NULL,	'+71111111111',	NULL,	'SELLER',	'NO',	'NO',	'2023-08-29 08:14:49',	'2023-08-29 08:14:57',	'id2');

DROP TABLE IF EXISTS `version`;
CREATE TABLE `version` (
  `db` varchar(9) NOT NULL,
  `front` varchar(9) NOT NULL,
  `back` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `version` (`db`, `front`, `back`) VALUES
('01.00.01',	'01.00.01',	'01.00.01');

DROP TABLE IF EXISTS `warehouse`;
CREATE TABLE `warehouse` (
  `id` varchar(50) NOT NULL,
  `idItem` varchar(50) NOT NULL,
  `idOwner` varchar(50) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `isDeleted` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp(),
  `idLastUserOperation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idItem_idOwner_isDeleted` (`idItem`,`idOwner`,`isDeleted`),
  KEY `idLastUserOperation` (`idLastUserOperation`),
  KEY `isDeleted` (`isDeleted`),
  KEY `idItem_isDeleted` (`idItem`,`isDeleted`),
  KEY `idOwner` (`idOwner`),
  CONSTRAINT `warehouse_ibfk_1` FOREIGN KEY (`idItem`) REFERENCES `categoryItems` (`id`),
  CONSTRAINT `warehouse_ibfk_2` FOREIGN KEY (`idLastUserOperation`) REFERENCES `users` (`id`),
  CONSTRAINT `warehouse_ibfk_3` FOREIGN KEY (`idOwner`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `warehouse` (`id`, `idItem`, `idOwner`, `quantity`, `isDeleted`, `created`, `updated`, `idLastUserOperation`) VALUES
('0aefaa5e-951f-420c-b827-f1947424f724',	'aa23906d-23a5-4844-b9b8-c1c9bb8f092b',	'id1',	0.00,	'NO',	'2023-08-22 17:43:36',	'2023-08-22 17:43:36',	'id1'),
('424464a9-7c2c-4bdd-9e6a-166acba1def6',	'27e361ae-4717-4c4c-acfc-b1de9d5ea1f5',	'id2',	0.00,	'NO',	'2023-08-29 09:14:45',	'2023-08-29 09:14:45',	'id2'),
('57ee1bc1-96d4-491e-906d-825b61689b94',	'27e361ae-4717-4c4c-acfc-b1de9d5ea1f5',	'id1',	50.00,	'NO',	'2023-08-22 16:42:39',	'2023-08-22 16:42:39',	'id1'),
('5a3311e5-2c64-4e44-9e73-155df0d00122',	'54b72536-e098-468a-8301-818393f55f28',	'id2',	45.00,	'NO',	'2023-08-29 17:52:52',	'2023-08-29 17:52:52',	'id2'),
('829fd026-1608-4ce1-ba6a-bbde4be4b5f4',	'54b72536-e098-468a-8301-818393f55f28',	'id1',	15.00,	'NO',	'2023-08-22 17:32:46',	'2023-08-22 17:32:46',	'id1'),
('c0fb91a1-b473-4ad5-9c9f-34a43fd246af',	'85874e33-116b-4294-a51d-e80e135bb98c',	'id2',	0.00,	'NO',	'2023-08-29 17:53:15',	'2023-08-29 17:53:15',	'id2'),
('cb6880d6-dbb0-4567-8c4c-fc3cc25d0545',	'85874e33-116b-4294-a51d-e80e135bb98c',	'id1',	0.00,	'NO',	'2023-08-22 17:14:34',	'2023-08-22 17:14:34',	'id1'),
('e1344139-94b4-4e6a-bc90-9caf6a1dca7d',	'56df2476-5a22-4e6d-8980-f6182d16115b',	'id2',	0.00,	'NO',	'2023-08-29 08:24:44',	'2023-08-29 08:24:44',	'id2'),
('e90e60a1-9e44-4e7a-8695-3a96ec5036be',	'aa23906d-23a5-4844-b9b8-c1c9bb8f092b',	'id2',	0.00,	'NO',	'2023-08-29 09:39:54',	'2023-08-29 09:39:54',	'id2'),
('id1',	'098099d1-c5d0-424c-b59f-11ec09c8a41c',	'id1',	20.00,	'NO',	'2023-08-22 16:14:52',	'2023-08-22 16:14:52',	'id1');

-- 2023-09-01 17:06:57
